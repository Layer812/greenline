@echo off
setlocal
cd /d "%~dp0"
echo [FIRST PERSON BIKE R1] StopWatch native firmware: BUILD ONLY
where pio >nul 2>&1
if not errorlevel 1 (
    pio run -e m5stack-stopwatch
) else (
    python -m platformio run -e m5stack-stopwatch
)
if errorlevel 1 (echo BUILD FAILED & exit /b 1)
echo PASS: BUILD COMPLETED. Firmware: .pio\build\m5stack-stopwatch\firmware.bin
echo FLASH IS NOT RUN BY THIS SCRIPT.
