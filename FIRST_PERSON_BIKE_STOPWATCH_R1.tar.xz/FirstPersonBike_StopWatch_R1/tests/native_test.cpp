#include "bike_physics.hpp"
#include <cassert>
#include <cmath>
#include <iostream>
int main(){
  using namespace bike;
  assert(height(74,1)>height(60,1));
  assert(height(161,2)>height(74,2));
  assert(height(701,0)>1.5f);
  assert(surface(320,1)==Surface::OIL);
  assert(surface(320,0)==Surface::ROAD);
  assert(surface(390,3)==Surface::SAND);
  assert(surface(446,2)==Surface::BOOST);
  State g;
  swipeLane(g,-1);swipeLane(g,-1);assert(g.lane==0);
  swipeLane(g,1);assert(g.lane==1);
  gesturePitch(g,1);assert(g.requestedPitch>.19f);
  gesturePitch(g,-1);assert(fabsf(g.requestedPitch)<.01f);
  for(int n=0;n<120;n++)step(g,1.f/60.f,true,false);
  assert(g.speed>15.f && g.s>10.f);
  State j;j.s=240.f;j.speed=30.f;j.y=height(j.s,1);
  bool launched=false,landed=false;
  for(int n=0;n<500;n++){
    step(j,1.f/60.f,true,false);
    if(j.event==Event::TAKEOFF)launched=true;
    if(j.event==Event::LANDED || j.event==Event::CRASH)landed=true;
  }
  assert(launched && landed);
  State lap;lap.s=719.f;lap.speed=30.f;lap.y=height(lap.s,lap.lane);
  for(int i=0;i<10;i++)step(lap,1.f/60.f,true,false);
  assert(lap.lap==2);
  std::cout<<"PASS bike physics / terrain / surfaces / controls / jump / lap\n";
}
