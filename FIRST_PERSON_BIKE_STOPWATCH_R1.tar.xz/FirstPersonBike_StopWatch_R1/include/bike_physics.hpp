#pragma once
// First Person Bike R1: standalone game simulation, no M5 dependencies.
#include <cmath>
#include <cstdint>
#include <algorithm>

namespace bike {
constexpr float kLength=720.0f;
constexpr int kLanes=4;
constexpr float kLaneWidth=3.15f;
constexpr float kPi=3.14159265358979323846f;

enum class Surface : uint8_t { ROAD, BOOST, OIL, SAND };
enum class Event : uint8_t { NONE, TAKEOFF, LANDED, CRASH, LAP };

inline float clampf(float x,float lo,float hi) {return std::max(lo,std::min(hi,x));}
inline float wrap(float s) { float t=fmodf(s,kLength);return t<0.f?t+kLength:t; }
inline float cyclicDelta(float s,float center) {
  float d=wrap(s)-center;
  if(d>kLength*.5f)d-=kLength;
  if(d<-kLength*.5f)d+=kLength;
  return d;
}
inline float dome(float s,float center,float radius,float height) {
  const float d=fabsf(cyclicDelta(s,center));
  if(d>=radius) return 0.f;
  return height*.5f*(1.f+cosf(kPi*d/radius));
}
inline bool within(float s,float start,float end) {
  s=wrap(s);return start<=end ? (s>=start&&s<end) : (s>=start||s<end);
}
inline float ramp(float s,float start,float end,float height) {
  const float x=wrap(s);
  if(x<start || x>=end) return 0.f;
  return (x-start)/(end-start)*height;
}
inline float height(float s,int lane) {
  (void)lane;
  // Two low bumps, two large hills, sharp take-off ramps, LAP mound.
  return dome(s,74.f,12.f,1.15f)
       + dome(s,161.f,22.f,3.8f)
       + ramp(s,223.f,243.f,3.4f)
       + dome(s,494.f,10.f,1.10f)
       + dome(s,553.f,21.f,3.7f)
       + ramp(s,628.f,645.f,3.0f)
       + dome(s,701.f,15.f,1.55f);
}
inline float slope(float s,int lane) {
  // 20 cm derivative used only for grounded bike attitude.
  return (height(s+.1f,lane)-height(s-.1f,lane))/.2f;
}
inline Surface surface(float s,int lane) {
  if(within(s,313.f,345.f) && lane==1) return Surface::OIL;
  if(within(s,354.f,404.f)) return Surface::SAND;
  if(within(s,430.f,466.f) && (lane==0||lane==2)) return Surface::BOOST;
  if(within(s,587.f,603.f) && lane==3) return Surface::OIL;
  return Surface::ROAD;
}
inline float laneX(float lane) {return (lane-1.5f)*kLaneWidth;}

struct State {
  float s=0.f;            // monotonic distance, meters
  float speed=0.f;        // meters/second
  float y=0.f;            // wheel contact height, meters
  float vy=0.f;
  float pitch=0.f;        // nose up positive, radians
  float requestedPitch=0.f;
  float pitchTimer=0.f;
  float laneView=1.f;
  int lane=1;
  float elapsed=0.f;
  float lapStart=0.f;
  float lastLap=0.f;
  float bestLap=0.f;
  float crashTime=0.f;
  int lap=1;
  bool airborne=false;
  bool oilSlip=false;
  bool finishedLap=false;
  Event event=Event::NONE;
  State() { y=height(s,lane); }
};

inline void swipeLane(State& g,int dir) {
  g.lane=std::max(0,std::min(kLanes-1,g.lane+dir));
}
inline void gesturePitch(State& g,int dir) {
  g.requestedPitch=clampf(g.requestedPitch+float(dir)*.21f,-.53f,.58f);
  g.pitchTimer=1.6f;
}
inline void step(State& g,float dt,bool throttle,bool brake) {
  g.event=Event::NONE;
  dt=clampf(dt,0.f,.06f);
  if(dt<=0.f)return;
  g.elapsed+=dt;
  if(g.crashTime>0.f) {
    g.crashTime=std::max(0.f,g.crashTime-dt);
    g.speed=std::max(0.f,g.speed-35.f*dt);
    if(g.crashTime<=0.f) {
      g.airborne=false;g.vy=0.f;g.pitch=0.f;g.requestedPitch=0.f;
      g.y=height(g.s,g.lane);
    }
    return;
  }
  const Surface surf=surface(g.s,g.lane);
  g.oilSlip=(surf==Surface::OIL && g.speed>9.f);
  const float drift=g.oilSlip?.12f*sinf(g.elapsed*12.f):0.f;
  g.laneView+=(float(g.lane)+drift-g.laneView)*std::min(1.f,dt*(g.oilSlip?2.3f:7.f));
  float accel=(throttle?15.f:0.f)-(brake?(g.oilSlip?10.f:32.f):0.f)-2.7f-g.speed*.085f;
  if(!g.airborne)accel-=std::max(0.f,slope(g.s,g.lane))*((g.requestedPitch>.12f)?3.0f:4.5f);
  if(surf==Surface::SAND)accel-=8.f;
  if(surf==Surface::BOOST)accel+=14.f;
  g.speed=clampf(g.speed+accel*dt,0.f,44.f);
  const float oldS=g.s;
  g.s+=g.speed*dt;
  if(int(oldS/kLength)!=int(g.s/kLength)) {
    g.lastLap=g.elapsed-g.lapStart;
    g.lapStart=g.elapsed;
    if(g.lastLap>5.f && (g.bestLap==0.f || g.lastLap<g.bestLap))g.bestLap=g.lastLap;
    ++g.lap;
    g.event=Event::LAP;
    g.finishedLap=true;
  }
  if(g.pitchTimer>0.f){g.pitchTimer=std::max(0.f,g.pitchTimer-dt);}
  else g.requestedPitch+=(0.f-g.requestedPitch)*dt*3.2f;
  const float h=height(g.s,g.lane);
  // Ramp exits have a vertical drop. Launch automatically at their lip.
  bool launch=false;
  bool hillJump=false;
  for(float exit: {243.f,645.f}) {
    const float n=floorf(oldS/kLength);
    for(int k=0;k<=1;k++){
      const float lip=(n+float(k))*kLength+exit;
      if(oldS<lip && g.s>=lip)launch=true;
    }
  }
  if(g.speed>28.f && g.requestedPitch>.12f) {
    for(float peak: {74.f,161.f,494.f,553.f,701.f}) {
      const float n=floorf(oldS/kLength);
      for(int k=0;k<=1;k++){
        const float crest=(n+float(k))*kLength+peak;
        if(oldS<crest && g.s>=crest)hillJump=true;
      }
    }
  }
  if((launch||hillJump)&&!g.airborne&&g.speed>7.f) {
    g.airborne=true;
    g.y=std::max(g.y,launch?2.9f:h);
    g.vy=launch?std::max(4.7f,g.speed*.19f):std::min(4.0f,g.speed*.105f);
    g.pitch=std::max(.12f,g.pitch);
    g.event=Event::TAKEOFF;
  }
  if(g.airborne) {
    g.y+=g.vy*dt;
    g.vy-=13.4f*dt;
    g.pitch+=(g.requestedPitch-g.pitch)*std::min(1.f,dt*3.1f);
    if(g.y<=h && g.vy<=0.f) {
      const float target=atanf(slope(g.s,g.lane))-.16f;
      const bool bad= fabsf(g.pitch-target)>.53f || (g.vy< -14.f && g.speed>25.f);
      g.y=h;g.vy=0.f;g.airborne=false;
      if(bad) {
        g.crashTime=1.25f;
        g.speed=std::min(g.speed,7.f);
        g.event=Event::CRASH;
      } else {
        g.event=Event::LANDED;
        g.pitch=g.pitch*.6f;
      }
    }
  } else {
    g.y=h;
    const float target=clampf(atanf(slope(g.s,g.lane))*.65f+g.requestedPitch*.95f,-.55f,.60f);
    g.pitch+=(target-g.pitch)*std::min(1.f,dt*8.f);
  }
}
}
