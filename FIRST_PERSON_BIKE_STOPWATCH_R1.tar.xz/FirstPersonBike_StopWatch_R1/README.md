# FIRST PERSON BIKE — StopWatch R1

M5Stack StopWatch (C152) の一人称バイクゲーム・ネイティブ試作。原作ROM・画像・音源は含まず、独自のコース・描画・物理実装です。

## 操作

- 黄色の左ボタン (M5 BtnA): 押している間アクセル
- 青色の右ボタン (M5 BtnB): 押している間ブレーキ
- 左右スワイプ: 4レーン間を移動
- 上スワイプ: ウィリー / ジャンプ中の後傾（車体の前輪が上がる）
- 下スワイプ: 前傾 / ジャンプ中の着地姿勢調整

## コース

周回 720 m。小さい山 x2、大きい山 x2、ジャンプ台 x2、オイル（レーン限定）x2、砂地、加速帯（レーン限定）、通常路面、LAP丘。空中姿勢と着地角度が適切でないと転倒。転倒後は自動復帰。LAP/タイム/ベストラップを表示。

## ビルド (Windows / PlatformIO)

`BUILD_ONLY.cmd`、またはこのフォルダで `pio run -e m5stack-stopwatch`。

ビルド後: `.pio/build/m5stack-stopwatch/firmware.bin`

依存は `M5Unified 0.3.0` / `M5GFX 0.3.0` を明示固定。ESP32-S3R8、16MB Flash、8MB OPI PSRAM、`BOARD_ID=30`。M5PM1 / M5IOE1 は M5Unified 側の同梱実装を利用し、別ライブラリを重複リンクしません。

**このZIPに自動フラッシュ機能はありません。** 既存のStopWatch開発規約R1に従い、書込には実機パーティション表とotadataの読み取り専用照合、現在・次回起動スロットの確定、およびAPP-only対象領域とBINサイズの検証が必要です。`partitions.csv` は既存Voyger系とのビルド互換用途であり、実機の領域情報だと決めつけないでください。`pio run -t upload`、`erase_flash`、パーティションテーブル書換は実施しないでください。

## 表示方式

`M5.begin(cfg)` で一度だけ初期化。自前のGPIO46操作・AMOLED電源/RESET操作・Display.init()は行いません。画面寸法は実行時取得。まず起動表示を直接描画し、その後にPSRAMスプライトを確保。スプライト利用時は表示転送DMAの終了を待ってから再描画。確保できないときは画面への直接描画にフォールバック。

## 検証範囲

純C++のゲーム物理テストは `g++ -std=c++11 -Iinclude tests/native_test.cpp -o test && ./test` で実行できます。ハードウェア向けビルドとStopWatch実機動作はこの配布物の作成環境では未検証です。

## 安全上の区別

ソース作成・ホストロジック検証 ≠ PlatformIOファームウェアビルド成功 ≠ 実機表示確認。本プロジェクトはR1初版のソース成果物であり、実機合格版と表記しません。
