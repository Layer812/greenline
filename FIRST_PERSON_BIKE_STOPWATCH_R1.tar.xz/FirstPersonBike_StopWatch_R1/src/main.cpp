// FIRST PERSON BIKE / M5Stack StopWatch R1 / native pseudo-3D
// M5Unified 0.3.0 + M5GFX 0.3.0. Original code, no ROM/assets.
#include <Arduino.h>
#include <M5Unified.h>
#include <M5GFX.h>
#include <cmath>
#include <cstdio>
#include <algorithm>
#include "bike_physics.hpp"

namespace {
constexpr int kSlices=52;
constexpr float kFar=95.f;
constexpr float kNear=1.35f;
M5Canvas frame(&M5.Display);
lgfx::LGFXBase* paint=&M5.Display;
bike::State player;
float depths[kSlices+1];
int W=0,H=0;
bool displayOK=false,hasSprite=false,wasTouch=false;
int startX=0,startY=0,markX=0,markY=0;
uint32_t lastSimUs=0,lastFrameMs=0,vibrationEnd=0,lapOverlayUntil=0,landOverlayUntil=0;
uint32_t bootMessageUntil=0;

uint16_t rgb(uint8_t r,uint8_t g,uint8_t b){
  return uint16_t((r>>3)<<11 | (g>>2)<<5 | (b>>3));
}
const uint16_t SKY=rgb(9,35,125), SKY2=rgb(20,51,155), BLACK=0x0000;
const uint16_t WHITE=0xFFFF, ROAD=rgb(33,106,211), ROAD_DARK=rgb(24,80,172);
const uint16_t EDGE=rgb(208,229,254), OIL=rgb(18,26,45), SAND=rgb(166,117,61);
const uint16_t BOOST=rgb(245,112,56), HUD=rgb(240,249,255);

struct Point {int x,y;};
int safeCoord(float v) {return int(bike::clampf(v,-2500.f,2500.f));}
Point project(float trackX,float altitude,float ahead) {
  const float camX=bike::laneX(player.laneView);
  const float camY=player.y+1.48f;
  const float f=float(W)*.565f;
  // Horizon travels downward when the front wheel lifts toward the sky.
  const float horizon=float(H)*.468f+player.pitch*float(H)*.33f;
  const float z=std::max(.62f,ahead);
  return {safeCoord(float(W)*.5f + (trackX-camX)*f/z),
          safeCoord(horizon + (camY-altitude)*f/z)};
}
void tri(Point a,Point b,Point c,uint16_t color) {
  paint->fillTriangle(a.x,a.y,b.x,b.y,c.x,c.y,color);
}
void quad(Point a,Point b,Point c,Point d,uint16_t color) {
  tri(a,b,c,color);tri(a,c,d,color);
}
void line(Point a,Point b,uint16_t color,int width=1){
  paint->drawLine(a.x,a.y,b.x,b.y,color);
  if(width>1)paint->drawLine(a.x+1,a.y,b.x+1,b.y,color);
}

void drawSky(){
  paint->fillScreen(SKY);
  const int horizon=safeCoord(float(H)*.468f+player.pitch*float(H)*.33f);
  // NES-era bands, rather than a realistic bitmap sky.
  paint->fillRect(0,0,W,std::max(0,std::min(H,horizon-65)),SKY);
  for(int i=0;i<5;i++) {
    const int yy=horizon-86+i*12;
    if(yy<0||yy>=H)continue;
    paint->fillRect(0,yy,W,13,rgb(uint8_t(12+i*3),uint8_t(47+i*4),uint8_t(138+i*5)));
  }
  // Low polygon grandstands and rails on the horizon.
  if(horizon>-30&&horizon<H+30){
    const int y=horizon-12;
    paint->fillRect(0,y,W,7,rgb(104,43,133));
    paint->fillRect(0,y+7,W,5,rgb(205,92,207));
    for(int x=4;x<W;x+=13){
      const int bob=((x*7)%19)<8?0:3;
      paint->fillRect(x,y-8+bob,6,4,rgb(234,206,246));
      paint->fillRect(x+2,y-4+bob,5,5,rgb(110,41,177));
    }
    paint->fillRect(0,y+13,W,9,SKY2);
  }
}

uint16_t roadColor(float meters,int lane,int slice) {
  switch(bike::surface(meters,lane)) {
    case bike::Surface::BOOST:return (slice&1)?BOOST:rgb(255,169,79);
    case bike::Surface::OIL:return (slice&1)?OIL:rgb(31,39,56);
    case bike::Surface::SAND:return (slice&1)?SAND:rgb(197,145,86);
    default:return (slice&1)?ROAD:ROAD_DARK;
  }
}

void drawRoad(){
  const float edgeLeft=bike::laneX(-.5f);
  const float edgeRight=bike::laneX(3.5f);
  // Paint back-to-front so nearby road edges occlude the horizon and far hills.
  for(int k=kSlices-1;k>=0;k--){
    const float nearZ=depths[k],farZ=depths[k+1];
    const float s0=player.s+nearZ,s1=player.s+farZ;
    const float mid=player.s+(nearZ+farZ)*.5f;
    // Dark track verge makes elevation changes legible at speed.
    Point a=project(edgeLeft-1.0f,bike::height(s0,0)-.08f,nearZ);
    Point b=project(edgeRight+1.0f,bike::height(s0,3)-.08f,nearZ);
    Point c=project(edgeRight+1.0f,bike::height(s1,3)-.08f,farZ);
    Point d=project(edgeLeft-1.0f,bike::height(s1,0)-.08f,farZ);
    quad(a,b,c,d,(k%4<2)?rgb(6,29,70):rgb(7,39,87));
    for(int lane=0;lane<bike::kLanes;lane++){
      float x0=bike::laneX(float(lane)-.5f),x1=x0+bike::kLaneWidth;
      Point nL=project(x0,bike::height(s0,lane),nearZ);
      Point nR=project(x1,bike::height(s0,lane),nearZ);
      Point fL=project(x0,bike::height(s1,lane),farZ);
      Point fR=project(x1,bike::height(s1,lane),farZ);
      quad(nL,nR,fR,fL,roadColor(mid,lane,int(mid/4.f)));
      // Visible dotted lane dividers from nearby to far distance.
      if(lane<bike::kLanes-1 && (int(mid/3.5f)%2==0))line(nR,fR,rgb(165,202,251));
      if(lane==0)line(nL,fL,EDGE,2);
      if(lane==bike::kLanes-1)line(nR,fR,EDGE,2);
      // Speed arrows on boost strips, white markings on ramps.
      if(bike::surface(mid,lane)==bike::Surface::BOOST && (int(mid/4.f)%3==0)){
        Point m=project((x0+x1)*.5f,bike::height(mid,lane)+.03f,(nearZ+farZ)*.5f);
        const int r=std::max(2,int(19.f/(2.f+nearZ*.24f)));
        line({m.x-r,m.y+r},{m.x,m.y-r},WHITE,2);
        line({m.x,m.y-r},{m.x+r,m.y+r},WHITE,2);
      }
      const float track=bike::wrap(mid);
      const bool isRamp=(track>223.f&&track<243.f)||(track>628.f&&track<645.f);
      if(isRamp && int(mid/2.f)%2==0)line(nL,nR,rgb(226,244,255));
    }
  }
}

void drawLapMarker(){
  // LAP is a special mound with its own over-road marker at x=701m.
  float z=bike::wrap(701.f-bike::wrap(player.s));
  if(z<4.f||z>36.f)return;
  const float h=bike::height(player.s+z,1);
  Point lb=project(bike::laneX(-.5f),h,z);
  Point rb=project(bike::laneX(3.5f),h,z);
  Point lt=project(bike::laneX(-.5f),h+3.f,z);
  Point rt=project(bike::laneX(3.5f),h+3.f,z);
  line(lb,lt,rgb(255,221,139),2);
  line(rb,rt,rgb(255,221,139),2);
  line(lt,rt,rgb(255,237,179),2);
  const int cx=(lt.x+rt.x)/2,cy=(lt.y+rt.y)/2-10;
  paint->setTextDatum(middle_center);
  paint->setFont(&fonts::FreeMonoBold12pt7b);
  paint->setTextColor(rgb(255,242,182));
  if(z<24.f)paint->drawString("LAP",cx,cy);
}

void drawBike(){
  // A rider's hands, raised handlebars and dash occupy the foreground.
  const int cx=W/2;
  const int baseY=int(H*.79f-player.pitch*float(H)*.18f-(player.airborne?12.f:0.f));
  const int gripY=baseY-18;
  const int gripDx=int(W*.26f);
  const uint16_t sleeve=rgb(32,41,71),glove=rgb(238,92,67);
  const uint16_t steel=rgb(190,206,225),rubber=rgb(9,15,25);
  // Orange sleeves from bottom edge to handle grips.
  tri({cx-int(W*.47f),H},{cx-int(W*.31f),H},{cx-gripDx,gripY+4},sleeve);
  tri({cx+int(W*.47f),H},{cx+int(W*.31f),H},{cx+gripDx,gripY+4},sleeve);
  tri({cx-int(W*.40f),H},{cx-int(W*.32f),H},{cx-gripDx,gripY+9},rgb(221,83,60));
  tri({cx+int(W*.40f),H},{cx+int(W*.32f),H},{cx+gripDx,gripY+9},rgb(221,83,60));
  // Handle bar crossbar, grips and hands.
  paint->drawLine(cx-gripDx,gripY,cx+gripDx,gripY,steel);
  paint->drawLine(cx-gripDx,gripY+2,cx+gripDx,gripY+2,rubber);
  paint->drawLine(cx,gripY+4,cx,baseY+38,steel);
  paint->fillRoundRect(cx-gripDx-21,gripY-7,48,15,7,rubber);
  paint->fillRoundRect(cx+gripDx-27,gripY-7,48,15,7,rubber);
  paint->fillCircle(cx-gripDx+2,gripY+6,13,glove);
  paint->fillCircle(cx+gripDx-2,gripY+6,13,glove);
  // Bike headlight fairing + dial.
  paint->fillTriangle(cx-48,baseY+42,cx+48,baseY+42,cx,baseY-10,rgb(17,28,49));
  paint->fillCircle(cx,baseY+25,43,steel);
  paint->fillCircle(cx,baseY+25,38,BLACK);
  paint->drawCircle(cx,baseY+25,34,rgb(55,152,220));
  paint->setTextDatum(middle_center);
  paint->setTextColor(WHITE);
  paint->setFont(&fonts::FreeMonoBold18pt7b);
  char v[16];snprintf(v,sizeof(v),"%d",int(player.speed*3.6f+.5f));
  paint->drawString(v,cx,baseY+23);
  paint->setFont(&fonts::FreeMonoBold12pt7b);
  paint->setTextColor(rgb(179,205,239));
  paint->drawString("KM/H",cx,baseY+59);
}

const char* surfaceName(bike::Surface s) {
  switch(s){
    case bike::Surface::BOOST:return "BOOST";
    case bike::Surface::SAND:return "SAND";
    case bike::Surface::OIL:return "OIL!";
    default:return "ROAD";
  }
}
void drawHUD(){
  paint->setTextDatum(middle_center);
  paint->setFont(&fonts::FreeMonoBold12pt7b);
  paint->setTextColor(HUD);
  char label[48];
  snprintf(label,sizeof(label),"LAP %d",player.lap);
  paint->drawString(label,W/2,int(H*.128f));
  snprintf(label,sizeof(label),"%02u:%05.2f",(unsigned)(player.elapsed/60),fmodf(player.elapsed,60.f));
  paint->drawString(label,W/2,int(H*.193f));
  snprintf(label,sizeof(label),"LN %d",player.lane+1);
  paint->drawString(label,int(W*.19f),int(H*.33f));
  paint->drawString(surfaceName(bike::surface(player.s,player.lane)),int(W*.81f),int(H*.33f));
  if(player.bestLap>0.f){
    snprintf(label,sizeof(label),"BEST %.2fs",player.bestLap);
    paint->drawString(label,W/2,int(H*.26f));
  }
  if(player.speed<.4f && player.crashTime<=0.f && player.elapsed<6.f){
    paint->setTextColor(rgb(255,240,174));
    paint->drawString("HOLD LEFT : GO",W/2,int(H*.62f));
  }
  const uint32_t now=millis();
  if(now<lapOverlayUntil){
    paint->setTextColor(rgb(255,237,138));
    paint->drawString("LAP!",W/2,int(H*.39f));
  } else if(now<landOverlayUntil){
    paint->setTextColor(rgb(163,255,196));
    paint->drawString("NICE LANDING",W/2,int(H*.39f));
  }
  if(player.airborne){
    paint->setTextColor(rgb(255,239,137));
    paint->drawString("AIRBORNE",W/2,int(H*.32f));
  }
  if(player.crashTime>0.f){
    paint->fillRoundRect(int(W*.21f),int(H*.39f),int(W*.58f),int(H*.18f),12,rgb(113,22,27));
    paint->setFont(&fonts::FreeMonoBold18pt7b);
    paint->setTextColor(WHITE);
    paint->drawString("CRASH!",W/2,int(H*.48f));
  }
}

void render(){
  if(hasSprite)M5.Display.waitDMA();
  else M5.Display.startWrite();
  drawSky();drawRoad();drawLapMarker();drawBike();drawHUD();
  if(hasSprite){
    frame.pushSprite(0,0);
    M5.Display.waitDMA();
  } else {
    M5.Display.endWrite();
  }
}

void touchControls(){
  // A single gesture sampler avoids duplicated flick/drag callbacks.
  const auto t=M5.Touch.getDetail();
  const bool down=t.isPressed();
  if(down){
    const int x=t.x,y=t.y;
    if(!wasTouch){startX=markX=x;startY=markY=y;}
    else {
      int dx=x-markX,dy=y-markY;
      // Dominant direction only; keep lateral changes discrete.
      if(abs(dx)>=39 && abs(dx)>abs(dy)*1.22f){
        bike::swipeLane(player,dx>0?1:-1);
        markX=x;markY=y;
      } else if(abs(dy)>=36 && abs(dy)>abs(dx)*1.22f){
        bike::gesturePitch(player,dy<0?1:-1);
        markX=x;markY=y;
      }
    }
  }
  wasTouch=down;
}

void startupScreen(){
  M5.Display.fillScreen(SKY);
  M5.Display.setTextDatum(middle_center);
  M5.Display.setTextColor(WHITE);
  M5.Display.setFont(&fonts::FreeMonoBold18pt7b);
  M5.Display.drawString("1ST PERSON",W/2,H/2-45);
  M5.Display.drawString("BIKE",W/2,H/2-5);
  M5.Display.setFont(&fonts::FreeMonoBold12pt7b);
  M5.Display.setTextColor(rgb(255,220,143));
  M5.Display.drawString("L: GO    R: STOP",W/2,H/2+55);
  M5.Display.drawString("SWIPE TO STEER",W/2,H/2+91);
}
void inputAndPhysics(){
  // M5.update exclusively in the Arduino loop; BtnA/B are held controls.
  M5.update();
  touchControls();
  const bool accel=M5.BtnA.isPressed();
  const bool brake=M5.BtnB.isPressed();
  const uint32_t now=micros();
  if(!lastSimUs){lastSimUs=now;return;}
  const float dt=float(uint32_t(now-lastSimUs))*1.e-6f;
  lastSimUs=now;
  // Substeps preserve speed/physics even when display DMA takes >60 ms.
  float remaining=bike::clampf(dt,0.f,.24f);
  bike::Event event=bike::Event::NONE;
  while(remaining>0.00001f){
    const float substep=std::min(remaining,.025f);
    bike::step(player,substep,accel,brake);
    if(player.event!=bike::Event::NONE)event=player.event;
    remaining-=substep;
  }
  const uint32_t ms=millis();
  switch(event){
    case bike::Event::TAKEOFF:
      vibrationEnd=ms+65;break;
    case bike::Event::LANDED:
      vibrationEnd=ms+90;landOverlayUntil=ms+800;break;
    case bike::Event::CRASH:
      vibrationEnd=ms+290;break;
    case bike::Event::LAP:
      vibrationEnd=ms+120;lapOverlayUntil=ms+950;break;
    default:break;
  }
  static bool motorOn=false;
  const bool wantMotor=ms<vibrationEnd;
  if(wantMotor!=motorOn){M5.Power.setVibration(wantMotor?130:0);motorOn=wantMotor;}
}
} // anonymous namespace

void setup(){
  Serial.begin(115200);
  auto cfg=M5.config();
  cfg.fallback_board=m5::board_t::board_M5StopWatch;
  cfg.internal_mic=false;cfg.internal_imu=false;cfg.internal_rtc=false;
  cfg.external_imu=false;cfg.external_rtc=false;
  cfg.internal_spk=true; // Keep the known-good Vinyl/Voyager power startup.
  M5.begin(cfg); // exactly once. Never call M5.Display.init().
  M5.Display.setRotation(0);
  W=M5.Display.width();H=M5.Display.height();
  displayOK=(W>=320 && H>=320 && W<=512 && H<=512 && int(M5.getBoard())==30);
  Serial.printf("FP_BIKE_R1: board=%d panel=%dx%d PSRAM=%u\n",int(M5.getBoard()),W,H,(unsigned)ESP.getPsramSize());
  if(!displayOK){Serial.println("STOP: unexpected StopWatch display/board");return;}
  M5.Display.setBrightness(168);
  startupScreen(); // immediate direct draw, before any sprite allocations.
  frame.setColorDepth(16);
  frame.setPsram(true);
  hasSprite=(frame.createSprite(W,H)!=nullptr);
  paint=hasSprite ? static_cast<lgfx::LGFXBase*>(&frame)
                  : static_cast<lgfx::LGFXBase*>(&M5.Display);
  for(int i=0;i<=kSlices;i++) {
    const float t=float(i)/float(kSlices);
    depths[i]=kNear*powf(kFar/kNear,t);
  }
  Serial.printf("FP_BIKE_R1: sprite=%s, OTA/partition untouched\n",hasSprite?"yes":"direct fallback");
  M5.Power.setVibration(0);
  bootMessageUntil=millis()+1400;
  lastFrameMs=millis();
  lastSimUs=micros();
}
void loop(){
  if(!displayOK){delay(250);return;}
  inputAndPhysics();
  const uint32_t ms=millis();
  const uint32_t interval=hasSprite?50:125;
  if(ms>=bootMessageUntil && uint32_t(ms-lastFrameMs)>=interval) {
    lastFrameMs=ms;
    render();
  }
  delay(1);
}
